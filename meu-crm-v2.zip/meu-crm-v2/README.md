# MEU CRM v2.0

Sistema de Gestão Comercial completo em React + Vite.

## Deploy na Vercel

### Via GitHub (recomendado)
1. Suba esta pasta como repositório no GitHub
2. Acesse [vercel.com](https://vercel.com) → **Add New Project**
3. Importe o repositório → clique **Deploy**

### Via Vercel CLI
```bash
npm i -g vercel
vercel login
vercel --prod
```

## Rodar localmente

```bash
npm install
npm run dev       # http://localhost:3000
npm run build     # build de produção
npm run preview   # preview do build
```

## Estrutura

```
meu-crm/
├── public/favicon.svg
├── src/
│   ├── App.jsx      ← aplicação completa
│   └── main.jsx     ← entry point
├── index.html
├── package.json
├── vite.config.js
└── vercel.json
```

## Primeiro acesso

Na primeira abertura aparece a tela de **criação da conta Admin**.
Após isso, login por e-mail + senha. Novos usuários são criados em
**Configurações → Usuários do Sistema**.

## Dados

Salvos no `localStorage` do navegador (por dispositivo).
Para sincronização entre dispositivos, integre Firebase ou Supabase.
